module Main where


-- PFL 2023/24 - Haskell practical assignment quickstart



main :: IO ()
main = do
    putStrLn "Haskell practical assignment "